<?php
namespace Simenic;

/**
 * @Entity @Table(name="osoba")
 **/
class Osoba
{
    /** @Id @Column(type="integer") @GeneratedValue  **/
    private $sifra;

    /** @Column(type="string") **/
    private $ime;

    /** @Column(type="string") **/
	private $prezime;

	
	public function __construct($podaci=null)
	{
		if($podaci==null){
			return;
		}
		$this->ime=$podaci->ime;
		$this->prezime=$podaci->prezime;

	}

	public function getSifra()
	{
		return $this->sifra;
	}

	public function setSifra($sifra)
	{
		$this->sifra = $sifra;
	}

	public function getIme()
	{
		return $this->ime;
	}

	public function setIme($ime)
	{
		$this->ime = $ime;
	}

	public function getPrezime()
	{
		return $this->prezime;
	}

	public function setPrezime($prezime)
	{
		$this->prezime = $prezime;
	}

	

}