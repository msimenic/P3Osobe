create database p3osobe default character set utf8mb4;
use p3osobe;
create table osoba(
    sifra int not null primary key auto_increment,
    ime varchar(255) not null,
    prezime varchar(255) not null
);
insert into osoba(ime,prezime)
values ('Maja','Šimenić 🖱️');
