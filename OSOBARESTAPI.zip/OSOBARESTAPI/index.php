<?php

require 'vendor/autoload.php';
use Simenic\Osoba;
use Simenic\Pomocno;

Flight::route('GET /v1/osobe', function(){
   $doctrineBootstrap = Flight::db();
   $em = $doctrineBootstrap->getEntityManager();
   $repozitorij=$em->getRepository('Simenic\Osoba');
   $osobe = $repozitorij->findAll();
   $podaci = $doctrineBootstrap->getJson($osobe);
   Flight::json(Pomocno::odgovor(false,'OK',json_decode($podaci)));

});



Flight::route('POST /v1/osoba', function(){
  if(strlen(Flight::request()->data->ime)===0){

    Flight::json(Pomocno::odgovor(true,'Ime obavezno',null));
    return;
  }
  if(strlen(Flight::request()->data->prezime)===0){
    Flight::json(Pomocno::odgovor(true,'Prezime obavezno',null));
    return;
  }
  $osoba = new Osoba(Flight::request()->data);
  $doctrineBootstrap = Flight::db();
  $em = $doctrineBootstrap->getEntityManager();
  $em->persist($osoba);
  $em->flush();
  $podaci = $doctrineBootstrap->getJson($osoba);
  Flight::json(Pomocno::odgovor(false,'OK',[json_decode($podaci)]));
  header("HTTP/1.1 201 Created");
});



Flight::route('PUT /v1/osoba/@sifra', function($sifra){ 
    $doctrineBootstrap = Flight::db();
    $em = $doctrineBootstrap->getEntityManager();
    $repozitorij=$em->getRepository('Simenic\Osoba');
    $osoba = $repozitorij->find($sifra);
    $osoba->setIme(Flight::request()->data->ime);
    $osoba->setPrezime(Flight::request()->data->prezime);
    $em->persist($osoba);
    $em->flush();
    Flight::json(Pomocno::odgovor(false,'OK',null));
  });

  Flight::route('DELETE /v1/osoba/@sifra', function($sifra){
    $doctrineBootstrap = Flight::db();
    $em = $doctrineBootstrap->getEntityManager();
    $repozitorij=$em->getRepository('Simenic\Osoba');
    $osoba = $repozitorij->find($sifra);
    $em->remove($osoba);
    $em->flush();
    Flight::json(Pomocno::odgovor(false,'OK',[$osoba]));
  });

Flight::route('/', function(){
  Flight::json(Pomocno::odgovor(true,'nepotpuni podaci'));
});

Flight::map('notFound', function(){
  Flight::json(Pomocno::odgovor(true,'nepotpuni podaci'));
});

require_once 'bootstrap.php';

Flight::register('db','DoctrineBootstrap');

Flight::start();