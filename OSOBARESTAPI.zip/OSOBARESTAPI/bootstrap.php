<?php

use Doctrine\ORM\Tools\Setup;
use Doctrine\ORM\EntityManager;

use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Normalizer\DateTimeNormalizer;


class DoctrineBootstrap
{
    private $entityManager;
    private $serializer;
    
    public function __construct()
    {
        $config = Setup::createAnnotationMetadataConfiguration([],true);
        $conn=[
            'dbname'=>'msimenic_20_20',
            'user'=>'msimenic_20_20',
            'password'=>'EWY6uDt3',
            'host'=>'localhost',
            'driver'=>'pdo_mysql',
            'charset'=>'utf8mb4',
            'driverOptions'=>[1002 => 'set names utf8mb4']
        ];
        $this->entityManager = EntityManager::create($conn,$config);

        $this->serializer = new Serializer([new ObjectNormalizer()],[new JsonEncoder()]);


    }

    public function getEntityManager()
    {
        return $this->entityManager;
    }

    public function getJson($podaci)
    {
        return $this->serializer->serialize($podaci,'json');
    }
}