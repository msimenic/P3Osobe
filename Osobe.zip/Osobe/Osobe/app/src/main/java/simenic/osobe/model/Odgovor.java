package simenic.osobe.model;

import java.util.List;

public class Odgovor {

    private Poruka poruka;
    private List<Osoba> podaci;

    public Poruka getPoruka() {
        return poruka;
    }

    public void setPoruka(Poruka poruka) {
        this.poruka = poruka;
    }

    public List<Osoba> getPodaci() {
        return podaci;
    }

    public void setPodaci(List<Osoba> podaci) {
        this.podaci = podaci;
    }
}
