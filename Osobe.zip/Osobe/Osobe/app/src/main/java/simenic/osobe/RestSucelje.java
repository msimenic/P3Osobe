package simenic.osobe;

import simenic.osobe.model.Odgovor;

public interface RestSucelje {

    public void zavrseno(Odgovor odgovor);

}
