package simenic.osobe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import simenic.osobe.model.Odgovor;
import simenic.osobe.model.Osoba;

public class Detalji extends AppCompatActivity implements RestSucelje {

    private Osoba osoba;
    private EditText ime;
    private EditText prezime;
    private Button nazad, dodaj, promjeni, obrisi;
    private RESTTask restTask;
    private Gson gson;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalji);
        ime = findViewById(R.id.ime);
        prezime = findViewById(R.id.prezime);
        nazad = findViewById(R.id.nazad);
        dodaj = findViewById(R.id.dodaj);
        promjeni = findViewById(R.id.promjeni);
        obrisi = findViewById(R.id.obrisi);

        Intent i = getIntent();
        boolean novaOsoba = i.getBooleanExtra("novaOsoba",false);
        if(!novaOsoba){
            osoba = (Osoba)i.getSerializableExtra("osoba");
            ime.setText(osoba.getIme());
            prezime.setText(osoba.getPrezime());
            dodaj.setVisibility(View.INVISIBLE);
        }else {
            promjeni.setVisibility(View.INVISIBLE);
            obrisi.setVisibility(View.INVISIBLE);
        }


        nazad.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                nazad(true);
            }
        });

        dodaj.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                dodaj();
            }
        });

        promjeni.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                promjeni();
            }
        });

        obrisi.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                obrisi();
            }
        });

        restTask = new RESTTask(this);

         gson = new GsonBuilder().create();


    }

    private void obrisi() {
        restTask.execute(getString(R.string.RESTAPI) + "osoba/" + osoba.getSifra(),"DELETE",null);
    }

    private void promjeni() {
        osoba.setIme(ime.getText().toString());
        osoba.setPrezime(prezime.getText().toString());
        restTask.execute(getString(R.string.RESTAPI) + "osoba/" + osoba.getSifra(),"PUT",gson.toJson(osoba));
    }

    private void dodaj() {
        osoba = new Osoba();
        osoba.setIme(ime.getText().toString());
        osoba.setPrezime(prezime.getText().toString());
        restTask.execute(getString(R.string.RESTAPI) + "osoba" ,"POST",gson.toJson(osoba));
    }

    void nazad(boolean ok){
        setResult(ok ? MainActivity.OK : MainActivity.GRESKA, null);
        finish();
    }


    @Override
    public void zavrseno(Odgovor odgovor) {
            nazad(!odgovor.getPoruka().isGreska());
    }
}
